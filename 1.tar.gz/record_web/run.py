from flask import Flask, jsonify, render_template
from flask_cors import cross_origin
import datetime
import oss2
from oss2.models import OSS_TRAFFIC_LIMIT
from config import accessKey, accessSecret, bucket_map

app = Flask(__name__)
auth = oss2.Auth(accessKey, accessSecret)

TWO_MINUTES = 60*2


def makelist(objects, name, bucket):
    limit_speed = (2000 * 1024 * 8)  # 2MB/s
    params = dict()
    params[OSS_TRAFFIC_LIMIT] = str(limit_speed)
    author = name
    title = '#'
    resp = [{
                'author': author,
                'title': title,
                'status': 'ok',
                'time': datetime.datetime.fromtimestamp(item.last_modified).isoformat(),
                'url': bucket.sign_url('GET', item.key, TWO_MINUTES)}for item in objects]
    return {'data': resp, 'code': 20000}


@app.route('/api/list/<name>')
@cross_origin()
def getlist(name):

    if name not in bucket_map:
        return "", 400

    bucket = oss2.Bucket(
        auth, 'http://oss-cn-hangzhou.aliyuncs.com', bucket_map[name])

    objects = []
    for obj in oss2.ObjectIterator(bucket):
        objects.append(obj)

    objects.sort(key=lambda item: item.last_modified, reverse=True)

    return jsonify(makelist(objects[:100], name, bucket))


@app.route('/')
def index():
    return render_template('index.html')


if __name__ == "__main__":
    app.run()
