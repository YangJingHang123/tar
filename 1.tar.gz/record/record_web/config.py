accessKey = 'LTAI4FcrNh9E5DDxZXU7A34B'
accessSecret = 'i3X4hyhn9mBD4RgAP55w062qnboIOA'

bucket_map = {}
bucket_map.update({'miki': 'supermikimiki'})
